# faster_indicators
Collection of charts used in weekly faster indicators releases

## See them in action
- [BICS ](https://onsvisual.github.io/faster_indicators/bics/)
- [Heatmap](https://onsvisual.github.io/faster_indicators/heatmap/)
- [Transport](https://onsvisual.github.io/faster_indicators/transport/)
- [Job vacancies](https://onsvisual.github.io/faster_indicators/vacs/)
- [Regional Job vacancies](https://onsvisual.github.io/faster_indicators/vacsregional/)
